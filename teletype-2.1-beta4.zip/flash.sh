dfu-programmer at32uc3b0512 erase
dfu-programmer at32uc3b0512 flash teletype.hex --suppress-bootloader-mem
dfu-programmer at32uc3b0512 start